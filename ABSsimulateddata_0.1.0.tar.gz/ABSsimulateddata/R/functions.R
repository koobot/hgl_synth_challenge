# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

#0. VM Function with adjustment for correlation matrix

load_packages_f <- function(x)
{if (length(setdiff(x, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(x, rownames(installed.packages())), repos = "http://cran.us.r-project.org")}
  else {lapply(x, require, character.only = TRUE)}}

#1 simulate continuous variables

#1.1 getting parameters for simulating the continuous variables


#--1.2 Vale M 1983 method

Simulatedata_continous_f = function (data,seed,negatives) {

  suppressWarnings(suppressMessages(library(dplyr)))
  suppressWarnings(suppressMessages(library(class)))

  #-- internal functions start (layer 1)

  '%ni%' <- Negate('%in%')

  continuous_parameters_f = function(data){

    suppressWarnings(suppressMessages(require(e1071)))    # load kurtosis and skewness functions

    rm_factor_col_f = function(x) x[, sapply(x, class) %ni% c("factor","character")]

    df =  data %>% rm_factor_col_f(.) # remove factor or character columns

    mu     = colMeans(df) #mu -> checks this may helps to ensure simulated values are around mean values
    Sigma  = cov(df) #covariance structure
    skew   = sapply(df, e1071::skewness) #skewness
    kurt   = sapply(df, e1071::kurtosis) #kurtosis
    return(list(length = dim(df)[1], mu = mu, Sigma = Sigma, skew = skew, kurt = kurt))
  }

  simluated_data_f = function(df.list,seed){
    #packages
    suppressWarnings(suppressMessages(require(semTools)))        #main tool withVale and Maurelli (1983) method
    #packages

    # n     -> no of obs
    # mu    -> checks this may helps to ensure simulated values are around mean values
    # Sigma -> corelation structure
    # skew  -> skewness
    # kurt  -> kurtosis

    set.seed(seed)
    output = mvrnonnorm(n=df.list[["length"]], mu=df.list[["mu"]], Sigma=df.list[["Sigma"]],
                        skewness = df.list[["skew"]], kurtosis = df.list[["kurt"]]) %>% as.data.frame()
    return(output)
  }
  #-- internal functions end (layer 1)

  df.list = continuous_parameters_f(data)

  # create simulated data
  out = simluated_data_f(df.list=df.list,seed=seed) %>% as.data.frame()

  #convert negatives to 0
  if(negatives==FALSE){
    out<-round((abs(out)+out)/2)
  }

  return(out)
}

Visits_permutation_f = function(user,n){
  #n determined the size of loop
  #functions start
  #--permutation based on df rows
  perm <- function(v) {
    n <- length(v)
    if (n == 1) v
    else {
      X <- NULL
      for (i in 1:n) X <- rbind(X, cbind(v[i], perm(v[-i])))
      X
    }
  }
  #--compare rows in matrices
  `%vinm%` <- function(x, matrix){
    test <- apply(matrix, 1, `==`, x)
    any(apply(test, 2, all))
  }

  visits=perm(1:ncol(user))

  if(nrow(user)>n){
    outputs = user
  } else {

    #--generate first random visits
    visits_sample = visits[sample(nrow(visits),size= n - nrow(user),replace=TRUE),]

    check = apply(user, 1, `%vinm%`, visits_sample)

    #--make sure the first random visits does not contain any user define visits

    while (identical(check,FALSE)==TRUE){
      visits_sample = visits[sample(nrow(visits),size= n - nrow(user),replace=TRUE),]
    }
    outputs = rbind(user,visits_sample)
  }

  return(outputs)
}

#--2. simulate categorical variables

Synthpop_categorical_f = function(df, v.sequence, syn.method, m, y, best.method) {

  suppressWarnings(suppressMessages(require(doSNOW)))
  suppressWarnings(suppressMessages(require(doParallel)))

  #--set up parallel computing
  cores=detectCores() -1
  cl <- makeCluster(cores[1])
  registerDoParallel(cores = cl)

  oritab = table(df[[y]])

  synoutputs<-foreach(i = 1:dim(v.sequence)[1]) %dopar% {
    suppressWarnings(suppressMessages(require(synthpop)))
    cart    = syn(df, visit.sequence = v.sequence[i,], seed = 567812523,
                  method=c(rep(syn.method,length(v.sequence[i,]))), drop.not.used = TRUE, m=m)
    pMSE    = utility.gen(cart,df)
    pScore  = chisq.test(rbind(cart$syn[[y]], table(df[[y]])))$p.value
    results = list(df=cart$syn,pMSE=c(pMSE$pMSE),pScore=pScore)
    return(results)
  }

  best.method.column = ifelse(best.method == "pMSE", 2, ifelse(best.method == "pSCORE", 3, warning("best.method not available")))

  if(m==1) {
    output  = synoutputs[[which.max(do.call(rbind,lapply(synoutputs, `[[`, best.method.column)))]][[1]]}
  else {
    output = do.call(c,lapply(synoutputs, `[[`, 1))[which.max(do.call(c,lapply(synoutputs, `[[`, best.method.column)))]
  }
  return(output)

  stopCluster(cl)
}


#--Plotting function

Plot_multibars_f = function(df, feature , label_column) {

  ABS_colours<-c("#336699","#669966","#99CC66","#993366")

  plt=ggplot(data=df, aes(x=eval(parse(text=feature)),y=..count..,fill=eval(parse(text=label_column)))) +
    geom_bar( stat="count", position ="dodge")  +
    scale_fill_manual("legend", values = ABS_colours) +
    theme(axis.title.y = element_blank(),
          axis.title.x = element_blank(),
          legend.title=element_blank(),
          legend.position = c(0.875, 0.9),
          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
          legend.key = element_rect(fill = "transparent"),
          legend.background = element_rect(fill="transparent")
    )
  return(plt)}

