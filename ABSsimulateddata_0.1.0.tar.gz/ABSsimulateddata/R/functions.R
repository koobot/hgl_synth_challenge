# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

#0. VM Function with adjustment for correlation matrix

load_packages_f <- function(x)
{if (length(setdiff(x, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(x, rownames(installed.packages())), repos = "http://cran.us.r-project.org")}
  else {lapply(x, require, character.only = TRUE)}}

#1 simulate continuous variables

#1.1 getting parameters for simulating the continuous variables


#--1.2 Vale M 1983 method

Simulated_continous_f = function (data,seed,negatives) {

  suppressWarnings(suppressMessages(library(dplyr)))

  #-- internal functions start (layer 1)

  '%ni%' <- Negate('%in%')

  continuous_parameters_f = function(data){

    suppressWarnings(suppressMessages(require(e1071)))    # load kurtosis and skewness functions

    rm_factor_col_f = function(x) x[, sapply(x, class) %ni% c("factor","character")]

    df =  data %>% rm_factor_col_f(.) # remove factor or character columns

    mu     = colMeans(df) #mu -> checks this may helps to ensure simulated values are around mean values
    Sigma  = cov(df) #covariance structure
    skew   = sapply(df, e1071::skewness) #skewness
    kurt   = sapply(df, e1071::kurtosis) #kurtosis
    return(list(length = dim(df)[1], mu = mu, Sigma = Sigma, skew = skew, kurt = kurt))
  }

  simluated_data_f = function(df.list,seed){
    #packages
    suppressWarnings(suppressMessages(require(semTools)))  #main tool withVale and Maurelli (1983) method
    #packages

    # n     -> no of obs
    # mu    -> checks this may helps to ensure simulated values are around mean values
    # Sigma -> corelation structure
    # skew  -> skewness
    # kurt  -> kurtosis

    set.seed(seed)
    output = mvrnonnorm(n=df.list[["length"]], mu=df.list[["mu"]],
                        Sigma=df.list[["Sigma"]], skewness = df.list[["skew"]],
                        kurtosis = df.list[["kurt"]]) %>% as.data.frame()
    return(output)
  }
  #-- internal functions end (layer 1)

  df.list = continuous_parameters_f(data)

  # create simulated data
  out = simluated_data_f(df.list=df.list,seed=seed) %>% as.data.frame()

  #convert negatives to 0
  if(negatives==FALSE){
    out<-round((abs(out)+out)/2)
  }

  return(out)
}

Visits_permutation_f = function(user,n){
  #n determined the size of loop
  #functions start
  #--permutation based on df rows
  perm <- function(v) {
    n <- length(v)
    if (n == 1) v
    else {
      X <- NULL
      for (i in 1:n) X <- rbind(X, cbind(v[i], perm(v[-i])))
      X
    }
  }
  #--compare rows in matrices
  `%vinm%` <- function(x, matrix){
    test <- apply(matrix, 1, `==`, x)
    any(apply(test, 2, all))
  }

  visits=perm(1:ncol(user))

  if(nrow(user)>n){
    outputs = user
  } else {

    #--generate first random visits
    visits_sample = visits[sample(nrow(visits),size= n - nrow(user),replace=TRUE),]

    check = apply(user, 1, `%vinm%`, visits_sample)

    #--make sure the first random visits does not contain any user define visits

    while (identical(check,FALSE)==TRUE){
      visits_sample = visits[sample(nrow(visits),size= n - nrow(user),replace=TRUE),]
    }
    outputs = rbind(user,visits_sample)
  }

  return(outputs)
}

#--2. synthpop categorical variables

Synthpop_categorical_f = function(df, v.sequence, syn.method, m, y, best.method) {

  suppressWarnings(suppressMessages(require(doSNOW)))
  suppressWarnings(suppressMessages(require(doParallel)))

  #--set up parallel computing
  cores=detectCores() -1
  cl <- makeCluster(cores[1])
  registerDoParallel(cores = cl)

  oritab = table(df[[y]])

  synoutputs<-foreach(i = 1:dim(v.sequence)[1]) %dopar% {
    suppressWarnings(suppressMessages(require(synthpop)))
    cart    = syn(df, visit.sequence = v.sequence[i,], seed = 567812523,
                  method=c(rep(syn.method,length(v.sequence[i,]))), drop.not.used = TRUE, m=m)
    pMSE    = utility.gen(cart,df)
    pScore  = chisq.test(rbind(cart$syn[[y]], table(df[[y]])))$p.value
    results = list(df=cart$syn,pMSE=c(pMSE$pMSE),pScore=pScore)
    return(results)
  }

  best.method.column = ifelse(best.method == "pMSE", 2, ifelse(best.method == "pSCORE", 3, warning("best.method not available")))

  if(m==1) {
    output  = synoutputs[[which.max(do.call(rbind,lapply(synoutputs, `[[`, best.method.column)))]][[1]]}
  else {
    output = do.call(c,lapply(synoutputs, `[[`, 1))[which.max(do.call(c,lapply(synoutputs, `[[`, best.method.column)))]
  }
  return(output)

  stopCluster(cl)
}

#--categorical variables

Parameters_categorical_f =  function(yVar, Xvars, data){
  library(nnet)
  #--functions

  get_xvars <- function(object, ...) {
    if(inherits(object, "formula")) {
      object <- terms(object)
    }
    y_index <- attr(object, "response")

    ## If there is something on the lhs of the formula,
    ## remove it and get vars
    if(y_index != 0) {
      object[[2]] <- NULL
      object <- terms(object)
    }
    all.vars(object, ...)
  }

  #--functions end

  collapse_factor_f = function(df, cols) {
    if (missing(cols) || is.na(cols) || cols == ""){
      #print("Please do not use numeric string only factor labels")
      stop("Please have at least a column")
      warning("Please have at least a column")
    } else if (length(cols)==1){
      out = as.factor(df[ , cols ])}
    else {
      out = as.factor(apply(df[ , cols ] , 1 , paste , collapse="_"))}
    return(out)
  }

  comb_factor = ifelse(length(yVar) == 1, data[yVar] , collapse_factor_f(df=data,cols=yVar))

  Xvarsm = c(Xvars, "0") #-- best using no intercept for the prediction results

  formu       = as.formula(paste0("factor ~ ", paste(Xvarsm, collapse = "+"))) # factor is the intermediate column name for the mnl regression

  dataCat     = data.frame(comb_factor,subset(data,select=(Xvars)))

  colnames(dataCat) = c("factor", Xvars)

  #-- determine the levels
  yvars  = levels(dataCat[["factor"]])[-1]

  model  = nnet::multinom(formu, dataCat, model=TRUE)

  coefs       = coef(model)

  comptab     = table(data[[yVar]])

  comb_factor = names(comptab)


  output = list(formu=formu, yvars = yvars , Xvar=get_xvars(formu),
                coefs=coefs , comptab=comptab,
                comb_factor=comb_factor, colNames=yVar)

  return(output)

}

Simulated_categorical_f = function (rep=10, yVar, Xvars, parameters) {

  #--functions

  Parameters_categorical_f =  function(yVar, Xvars, data){
    library(nnet)
    #--functions

    get_xvars <- function(object, ...) {
      if(inherits(object, "formula")) {
        object <- terms(object)
      }
      y_index <- attr(object, "response")

      ## If there is something on the lhs of the formula,
      ## remove it and get vars
      if(y_index != 0) {
        object[[2]] <- NULL
        object <- terms(object)
      }
      all.vars(object, ...)
    }

    #--functions end

    collapse_factor_f = function(df, cols) {
      if (missing(cols) || is.na(cols) || cols == ""){
        #print("Please do not use numeric string only factor labels")
        stop("Please have at least a column")
        warning("Please have at least a column")
      } else if (length(cols)==1){
        out = as.factor(df[ , cols ])}
      else {
        out = as.factor(apply(df[ , cols ] , 1 , paste , collapse="_"))}
      return(out)
    }

    comb_factor = ifelse(length(yVar) == 1, data[yVar] , collapse_factor_f(df=data,cols=yVar))

    Xvarsm = c(Xvars, "0") #-- best using no intercept for the prediction results

    formu       = as.formula(paste0("factor ~ ", paste(Xvarsm, collapse = "+"))) # factor is the intermediate column name for the mnl regression

    dataCat     = data.frame(comb_factor,subset(data,select=(Xvars)))

    colnames(dataCat) = c("factor", Xvars)

    #-- determine the levels
    yvars  = levels(dataCat[["factor"]])[-1]

    model  = nnet::multinom(formu, dataCat, model=TRUE)

    coefs       = coef(model)

    comptab     = table(data[[yVar]])

    comb_factor = names(comptab)


    output = list(formu=formu, yvars = yvars , Xvar=get_xvars(formu),
                  coefs=coefs , comptab=comptab,
                  comb_factor=comb_factor, colNames=yVar)

    return(output)

  }

  Multinominal_categorical_data_f = function (data,formu,yvars,Xvar,coefs,check) {

    #-- functions
    multinominal_sample_f= function(dflist,Blist,Xlist,check) {

      Denominator_paste_f = function(x,y){
        paste0("1+",paste("exp(",x,"*",y,")",collapse = "+"))
      }

      VProb_paste_f = function(Blist,Xlist) {
        cal_paste_f = function(x,y){
          return(paste("exp(",x,"*",y,")/Denominator",collapse = "+"))
        }
        formu=lapply(Blist,cal_paste_f,y=Xlist)
        return(paste0("cbind(1/Denominator,",paste0(formu,collapse=","),")",collapse =","))
      }

      get_df_f = function(dflist){
        for (i in 1:length(dflist)) {
          assign(names(dflist)[[i]],dflist[[i]],envir = .GlobalEnv)
        }
      }

      #get data.frames according to the 'dflist'
      get_df_f(data)

      #Calculation of denominator for probability calculation
      Denominator = eval(parse(text=Denominator_paste_f(unlist(Blist,recursive=FALSE,use.names = FALSE),Xlist)))

      #Calculating the matrix of probabilities for the choices in y
      if(length(Xlist)==1){
        vProb = eval(parse(text=VProb_paste_f(unlist(Blist,recursive=FALSE,use.names = FALSE),Xlist)))
      } else {
        vProb = eval(parse(text=VProb_paste_f(Blist,Xlist)))
      }

      # Assigning the value one to maximum probability and zero for rest to get the appropriate choices for value of x
      mChoices = t(apply(vProb, 1, rmultinom, n = 1, size = 1))

      # Value of Y and X together
      dfM = data.frame(y=apply(mChoices, 1, function(x) which(x==1)),do.call(cbind,dflist))

      return(list(dfM,VProb_paste_f(Blist,Xlist)))

    }

    #--create a df list with X variables
    xlist=list()
    for (i in 1:length(Xvar)) {xlist[i]=paste0("setNames(list(",data[Xvar[i]],"),'",Xvar[i],"')")}
    dflist = sapply(xlist, function(x) eval(parse(text=x)))

    #--create a Clist for the beta coefficients

    if("TRUE" %in% grepl("0", formu, fixed = TRUE) & length(Xvar)==1){
      Clist=sapply(1:length(yvars),  function(y) paste0("Beta",y,"=coefs[",y,"]"))
    } else {
      Cmatrix=sapply(1:length(yvars), function(x) sapply(seq(x,(length(Xvar)*length(yvars)),length(yvars)), function(y) paste0("Beta",y,"=coefs[",y,"]")))
      Clist=lapply(seq_len(ncol(Cmatrix)), function(i) Cmatrix[,i])
    }

    temp=list()
    for(i in 1:length(Clist)) {
      temp[[i]]=paste0(yvars[[i]],"=list(",do.call(paste,c(as.list(Clist[[i]]),sep=",")),")",collapse=",") #https://stackoverflow.com/questions/2098368/concatenate-a-vector-of-strings-character
    }

    Blist = eval(parse(text=paste0("list(",do.call(paste, c(as.list(temp), sep = ",")),")",collapse = ",")))

    simdata = multinominal_sample_f(dflist=dflist,Blist=Blist,Xlist=Xvar,check=check)

    if(check==TRUE)
    { return(simdata)}
    else
    {return(simdata[1])}

  }

  score_multinominal_f= function(nrep=10,df.list) {
    # create a y vector
    output = Multinominal_categorical_data_f(data=df.list[["data"]],formu=df.list[["formu"]],yvars=df.list[["yvars"]],Xvar=df.list[["Xvar"]],coefs=df.list[["coefs"]],check=TRUE)
    # check similarity
    score   = chisq.test(rbind(table(output$y), df.list[["comptab"]]))$p.value
    return(list(output, score))
  }

  recode_numeric_f = function(sim_factor, ori_factor) {
    #convert into string
    library(dplyr)
    sim_factor = deparse(substitute(sim_factor))
    return(eval(parse(text=paste0("recode(as.factor(",sim_factor,"),",paste(shQuote(1:length(ori_factor)),shQuote(ori_factor),collapse=",",sep="="),")"))))
  }

  split_factor_f = function(fac_col,colNames){
    require(stringr)
    out=as.data.frame(stringr::str_split_fixed(fac_col, "_", length(colNames)))
    out[sapply(out, is.character)] <- lapply(out[sapply(out, is.character)],as.factor)
    colnames(out)=colNames
    return(out)
  }

  #--functions end

  if(is.data.frame(parameters)==TRUE){
    data_categorical_pram = Parameters_categorical_f(yVar=yVar, Xvars=Xvars, data=parameters) ; data_categorical_pram$data = data
  } else {
    data_categorical_pram = parameters
  }

  rep_sim_data = replicate(rep, score_multinominal_f(df.list=data_categorical_pram), simplify = FALSE )

  best_mnl=which.max(do.call(rbind, sapply(rep_sim_data,function(x) x[2])))

  simdata =  unlist(rep_sim_data[[best_mnl]][[1]],recursive = FALSE)

  output = data.frame(split_factor_f(fac_col=recode_numeric_f(sim_factor=simdata$y,
                                                              ori_factor=data_categorical_pram$comb_factor),
                                     colNames=data_categorical_pram$colNames))


  return(output)

}

#--Plotting function

Plot_multibars_f = function(df, feature , label_column, type) {

  library(ggplot2); library(dplyr)

  ABS_colours<-c("#336699","#669966","#99CC66","#993366")

  if(type=="counts") {

  plt=ggplot(data=df, aes(x=eval(parse(text=feature)),y=..count..,fill=eval(parse(text=label_column)))) +
      geom_bar( stat="count", position ="dodge")

  } else {

  plt=ggplot(as.data.frame(df %>% dplyr::group_by_(.dots=c(label_column,feature)) %>%
                               summarise (n = n()) %>%
                               mutate(proportion = n / sum(n))),
               aes(x=eval(parse(text=paste0("as.factor(",feature,")"))),
                   y=proportion,fill=eval(parse(text=paste0("as.factor(",label_column,")"))))) +
      geom_bar(stat="identity", position="dodge")
  }

  plt=plt + scale_fill_manual("legend", values = ABS_colours) +
    theme(axis.title.y = element_blank(),
          axis.title.x = element_blank(),
          legend.title=element_blank(),
          legend.position = c(0.875, 0.95),
          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
          legend.key = element_rect(fill = "transparent"),
          legend.background = element_rect(fill="transparent")
    )
  return(plt)}
