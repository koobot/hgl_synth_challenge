packages =  c("haven","DescTools","foreign","ggplot2",
              "reshape2","stargazer","synthpop","plyr",
              "dplyr","nnet","MuMIn","lme4","purrr",
              "e1071", "semTools", "scales", "corpcor",
              "semTools","doSNOW","doParallel")

load_packages_f(packages)

#--load data
load(file='./data/satgpa.rda')
data = satgpa
data$sex = as.factor(data$sex); levels(data$sex) = c("male","female")
data=as.data.frame(data)

#pack <- available.packages()
#pack["graphics","Depends"]

# #--set up parallel computing
# cores=detectCores() -1
# cl <- makeCluster(cores[1])
# registerDoParallel(cores = cl)
#
# #--Vale M 1983
#
# simulated_continuous = Simulatedata_continous_f(data=data %>% select(-sat_sum),
#                                                 seed=123456,negatives=FALSE) %>%
#       mutate(sat_sum = sat_v + sat_m)
#
# #--CART method
#
# uservisit2 <- c(6:1)
# # creating visit matrix
# uservisits=matrix(rbind(uservisit1,uservisit2),nrow=2)
# #--determine maximum number of runs
# uservisits=Visits_permutation_f(user=
#         matrix(rbind(c(1,5,4,2,3,6),c(6:1)),nrow=2),n=5)
#
# simulated_categorical=Synthpop_categorical_f(df=data, v.sequence=uservisits,
#                                                  syn.method="cart", m=2, y="sex",
#                                                  best.method="pSCORE")
